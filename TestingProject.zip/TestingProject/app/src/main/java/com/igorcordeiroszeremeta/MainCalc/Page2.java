package com.igorcordeiroszeremeta.MainCalc;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Page2 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstaceState) {
        super.onCreate(savedInstaceState);
        setContentView(R.layout.page2layout);
    }
}
